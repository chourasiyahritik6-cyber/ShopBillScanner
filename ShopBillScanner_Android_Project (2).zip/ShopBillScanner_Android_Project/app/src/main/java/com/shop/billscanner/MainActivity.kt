package com.shop.billscanner

import android.app.*
import android.content.*
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.text.InputType
import android.view.*
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.File
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.*

data class BillRow(var raw: String, var item: String, var qty: Double, var amount: Double)

class MainActivity : AppCompatActivity() {

    private lateinit var status: TextView
    private var cameraUri: Uri? = null
    private val prefs by lazy { getSharedPreferences("shop", MODE_PRIVATE) }

    private val cameraLauncher = registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok && cameraUri != null) runOcr(cameraUri!!)
    }

    private val galleryLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) runOcr(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.status)

        findViewById<Button>(R.id.scanButton).setOnClickListener { takePhoto() }
        findViewById<Button>(R.id.galleryButton).setOnClickListener { galleryLauncher.launch("image/*") }
        findViewById<Button>(R.id.stockButton).setOnClickListener { manualStockDialog() }
        findViewById<Button>(R.id.secureButton).setOnClickListener { secureArea() }

        if (!prefs.contains("passwordHash")) setPasswordDialog()
    }

        private fun takePhoto() {
        val file = File.createTempFile("bill_", ".jpg", cacheDir)
        cameraUri = Uri.fromFile(file)
        
        val values = android.content.ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "bill_${System.currentTimeMillis()}.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
        }
        
        cameraUri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        
        val stableUri = cameraUri
        if (stableUri == null) {
            Toast.makeText(this, "Could not open camera.", Toast.LENGTH_SHORT).show()
            return
        }
        cameraLauncher.launch(stableUri)
    }


    private fun runOcr(uri: Uri) {
        status.text = "Scanning…"
        try {
            val image = InputImage.fromFilePath(this, uri)
            val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            recognizer.process(image)
                .addOnSuccessListener { result ->
                    recognizer.close()
                    showVerifyScreen(result.text)
                }
                .addOnFailureListener {
                    recognizer.close()
                    status.text = "OCR failed: ${it.message}"
                }
        } catch (e: Exception) {
            status.text = "Could not read image: ${e.message}"
        }
    }

    private fun showVerifyScreen(rawText: String) {
        val rows = parseRows(rawText)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(30, 20, 30, 10)
        }

        box.addView(TextView(this).apply {
            text = "EXACT SCANNED TEXT (not corrected)"
            textSize = 18f
            setTypeface(null, android.graphics.Typeface.BOLD)
        })

        val raw = EditText(this).apply {
            setText(rawText)
            minLines = 8
            gravity = Gravity.TOP
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        }
        box.addView(raw)

        box.addView(TextView(this).apply {
            text = "Bill rows — verify before finalizing"
            textSize = 18f
            setPadding(0, 20, 0, 8)
        })

        val rowContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        box.addView(rowContainer)

        rows.forEachIndexed { index, row ->
            addRowEditor(rowContainer, row, index + 1)
        }

        val totalText = TextView(this).apply {
            textSize = 20f
            setPadding(0, 15, 0, 15)
        }
        box.addView(totalText)

        fun recalc() {
            var total = 0.0
            for (i in 0 until rowContainer.childCount) {
                val holder = rowContainer.getChildAt(i) as LinearLayout
                val amount = (holder.getChildAt(3) as EditText).text.toString().toDoubleOrNull() ?: 0.0
                total += amount
            }
            totalText.text = "Calculated Total: ₹${"%.2f".format(total)}"
        }
        recalc()

        for (i in 0 until rowContainer.childCount) {
            val holder = rowContainer.getChildAt(i) as LinearLayout
            (holder.getChildAt(3) as EditText).setOnFocusChangeListener { _, _ -> recalc() }
        }

        AlertDialog.Builder(this)
            .setTitle("Verify Bill")
            .setView(box)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("FINALIZE BILL") { _, _ ->
                val finalRows = mutableListOf<BillRow>()
                for (i in 0 until rowContainer.childCount) {
                    val h = rowContainer.getChildAt(i) as LinearLayout
                    val item = (h.getChildAt(1) as EditText).text.toString()
                    val qty = (h.getChildAt(2) as EditText).text.toString().toDoubleOrNull() ?: 1.0
                    val amount = (h.getChildAt(3) as EditText).text.toString().toDoubleOrNull() ?: 0.0
                    finalRows.add(BillRow(rawText, item, qty, amount))
                }
                finalizeBill(rawText, finalRows)
            }
            .show()
    }

    private fun addRowEditor(parent: LinearLayout, row: BillRow, number: Int) {
        val h = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 4, 0, 4)
        }
        h.addView(TextView(this).apply {
            text = "$number."
            layoutParams = LinearLayout.LayoutParams(34, -2)
        })
        val item = EditText(this).apply {
            hint = "Item"
            setText(row.item)
            layoutParams = LinearLayout.LayoutParams(0, -2, 2f)
        }
        val qty = EditText(this).apply {
            hint = "Qty"
            setText(if (row.qty == 1.0) "1" else row.qty.toString())
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            layoutParams = LinearLayout.LayoutParams(0, -2, 0.8f)
        }
        val amount = EditText(this).apply {
            hint = "Amount"
            setText(if (row.amount == 0.0) "" else row.amount.toString())
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
        h.addView(item); h.addView(qty); h.addView(amount)
        parent.addView(h)
    }

    private fun parseRows(raw: String): MutableList<BillRow> {
        val out = mutableListOf<BillRow>()
        raw.lines().map { it.trim() }.filter { it.isNotEmpty() }.forEach { line ->
            val m = Regex("""(?:₹|Rs\.?|INR)?\s*([0-9]+(?:\.[0-9]+)?)\s*$""", RegexOption.IGNORE_CASE).find(line)
            val amount = m?.groupValues?.get(1)?.toDoubleOrNull() ?: 0.0
            val item = if (m != null) line.substring(0, m.range.first).trim() else line
            out.add(BillRow(line, item, 1.0, amount))
        }
        return out
    }

    private fun finalizeBill(raw: String, rows: List<BillRow>) {
        val total = rows.sumOf { it.amount }
        val date = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())
        val bill = "DATE: $date\nTOTAL: ₹$total\n\nEXACT OCR TEXT:\n$raw"
        val old = prefs.getString("bills", "") ?: ""
        prefs.edit().putString("bills", old + "\n--- BILL ---\n" + bill).apply()

        // Update stock only from verified rows.
        rows.forEach { row ->
            if (row.item.isNotBlank() && row.qty > 0) {
                val key = "stock_${row.item}"
                val oldQty = prefs.getFloat(key, 0f).toDouble()
                prefs.edit().putFloat(key, (oldQty + row.qty).toFloat()).apply()
            }
        }
        status.text = "Bill finalized. Total ₹${"%.2f".format(total)}. Stock updated."
        Toast.makeText(this, "Bill finalized successfully.", Toast.LENGTH_LONG).show()
    }

    private fun manualStockDialog() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(30, 10, 30, 10)
        }
        val item = EditText(this).apply { hint = "Item name exactly as you want to save" }
        val qty = EditText(this).apply {
            hint = "Quantity"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        }
        layout.addView(item); layout.addView(qty)
        AlertDialog.Builder(this)
            .setTitle("Manual Stock Update")
            .setView(layout)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Add") { _, _ ->
                val name = item.text.toString().trim()
                val q = qty.text.toString().toDoubleOrNull() ?: 0.0
                if (name.isNotBlank() && q > 0) {
                    val key = "stock_$name"
                    val old = prefs.getFloat(key, 0f).toDouble()
                    prefs.edit().putFloat(key, (old + q).toFloat()).apply()
                    status.text = "Added $q of $name to stock."
                }
            }.show()
    }

    private fun secureArea() {
        askPassword { showSecureSummary() }
    }

    private fun showSecureSummary() {
        val bills = prefs.getString("bills", "") ?: ""
        val totalPurchase = Regex("""TOTAL: ₹([0-9]+(?:\.[0-9]+)?)""")
            .findAll(bills).sumOf { it.groupValues[1].toDoubleOrNull() ?: 0.0 }

        val msg = "Purchase/Bill total recorded: ₹${"%.2f".format(totalPurchase)}\n\n" +
                "Sales entry and profit reporting are protected behind this password area.\n\n" +
                "Profit = Verified Sales − Verified Purchase Cost.\n" +
                "Add sales records here after verification."
        AlertDialog.Builder(this)
            .setTitle("🔒 Secure Financial Area")
            .setMessage(msg)
            .setPositiveButton("OK", null)
            .show()
    }

    private fun setPasswordDialog() {
        val input = EditText(this).apply {
            hint = "Create password"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        AlertDialog.Builder(this)
            .setTitle("Create Financial Password")
            .setMessage("This password protects purchase amount, selling amount and profit.")
            .setView(input)
            .setCancelable(false)
            .setPositiveButton("Save") { _, _ ->
                val p = input.text.toString()
                if (p.length >= 4) {
                    prefs.edit().putString("passwordHash", sha256(p)).apply()
                } else {
                    Toast.makeText(this, "Use at least 4 characters.", Toast.LENGTH_LONG).show()
                    setPasswordDialog()
                }
            }.show()
    }

    private fun askPassword(onSuccess: () -> Unit) {
        val input = EditText(this).apply {
            hint = "Password"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        AlertDialog.Builder(this)
            .setTitle("Enter Financial Password")
            .setView(input)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Unlock") { _, _ ->
                if (sha256(input.text.toString()) == prefs.getString("passwordHash", "")) {
                    onSuccess()
                } else {
                    Toast.makeText(this, "Wrong password.", Toast.LENGTH_SHORT).show()
                }
            }.show()
    }

    private fun sha256(s: String): String {
        return MessageDigest.getInstance("SHA-256")
            .digest(s.toByteArray())
            .joinToString("") { "%02x".format(it) }
    }
}
