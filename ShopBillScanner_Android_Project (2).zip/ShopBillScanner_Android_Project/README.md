# Shop Bill Scanner

Android app starter for a small shop.

## Main workflow

Photo/Camera → OCR → **preserve the scanned text exactly** → suggested bill rows → user verification/edit → calculated total → **Finalize Bill** → save bill + update stock.

### Important behavior
- OCR text is kept separately as the raw scanned text.
- The app does not automatically correct spelling or item names.
- Unclear/non-numeric rows are not silently invented; their amount remains blank/zero for verification.
- The user must press **FINALIZE BILL** before the bill is saved and stock is updated.
- Manual stock entry is available when a distributor does not provide a proper bill.
- Purchase/financial information is behind a password created on first launch.

## Open
Open this folder in Android Studio and let Gradle sync/download dependencies.

## Build
Run on an Android phone with Camera permission enabled.

## Next upgrades
- Better table/line-item OCR for bills with columns.
- Date/day/week/month financial dashboards.
- Separate selling-entry screen.
- Profit = verified sales - verified purchase cost.
- Stock deduction when a sale is finalized.
- Export/backup to Excel or PDF.
- Product aliases without changing the original OCR text.
